class AddListingFkColToProductboardposts < ActiveRecord::Migration[7.0]
  def change
    add_reference :productboardposts, :listing, foreign_key: true
  end
end
