class CreateCollections < ActiveRecord::Migration[7.0]
  def change
    create_table :collections do |t|
      t.integer :blue_count
      t.integer :red_count
      t.integer :green_count
      t.integer :pink_count

      t.timestamps
    end
  end
end
