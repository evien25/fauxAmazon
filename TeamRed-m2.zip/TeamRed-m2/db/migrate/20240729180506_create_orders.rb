class CreateOrders < ActiveRecord::Migration[7.0]
  def change
    create_table :orders do |t|
      t.string :first_name
      t.string :last_name
      t.string :email
      t.integer :zip
      t.decimal :total
      t.integer :points
      t.string :street_address
      t.string :street_address_2
      t.string :city
      t.string :state
      t.string :card_number
      t.integer :cvc
      t.date :exp

      t.timestamps
    end
  end
end
