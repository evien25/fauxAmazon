# == Schema Information
#
# Table name: answers
#
#  id           :bigint           not null, primary key
#  answer       :string           not null
#  question_num :integer          not null
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#  quiz_id      :bigint           not null
#
# Indexes
#
#  index_answers_on_quiz_id  (quiz_id)
#
# Foreign Keys
#
#  fk_rails_...  (quiz_id => quizzes.id)
#
require "test_helper"

class AnswerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
