# == Schema Information
#
# Table name: collections
#
#  id          :bigint           not null, primary key
#  blue_count  :integer
#  green_count :integer
#  pink_count  :integer
#  red_count   :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  user_id     :bigint
#
require "test_helper"

class CollectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
