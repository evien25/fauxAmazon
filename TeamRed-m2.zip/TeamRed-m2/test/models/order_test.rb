# == Schema Information
#
# Table name: orders
#
#  id               :bigint           not null, primary key
#  card_number      :string
#  city             :string
#  cvc              :integer
#  email            :string
#  exp              :date
#  first_name       :string
#  last_name        :string
#  points           :integer
#  state            :string
#  street_address   :string
#  street_address_2 :string
#  total            :decimal(, )
#  zip              :integer
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  user_id          :bigint
#
# Indexes
#
#  index_orders_on_user_id  (user_id)
#
# Foreign Keys
#
#  fk_rails_...  (user_id => users.id)
#
require "test_helper"

class OrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
