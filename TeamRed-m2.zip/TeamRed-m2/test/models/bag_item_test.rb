# == Schema Information
#
# Table name: bag_items
#
#  id           :bigint           not null, primary key
#  price        :decimal(, )
#  product_name :string
#  quantity     :integer
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#  bag_id       :bigint
#  listing_id   :bigint
#  orders_id    :bigint
#
# Indexes
#
#  index_bag_items_on_bag_id     (bag_id)
#  index_bag_items_on_orders_id  (orders_id)
#
# Foreign Keys
#
#  fk_rails_...  (bag_id => bags.id)
#  fk_rails_...  (orders_id => orders.id)
#
require "test_helper"

class BagItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
