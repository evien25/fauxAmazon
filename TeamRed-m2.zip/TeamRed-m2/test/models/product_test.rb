# == Schema Information
#
# Table name: products
#
#  id                  :bigint           not null, primary key
#  color               :string
#  popular             :boolean
#  price               :float
#  product_description :text
#  product_name        :string
#  quantity            :integer
#  size                :string
#  times_bought        :integer
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#
require "test_helper"

class ProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
