# == Schema Information
#
# Table name: listings
#
#  id                  :bigint           not null, primary key
#  color               :string
#  price               :float
#  product_description :text
#  product_name        :string
#  size                :string
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#
class Listing < ApplicationRecord

  has_many_attached :images

  validates :product_name, presence: true, uniqueness: true
  validates :price, presence: true
  

  def self.ransackable_attributes(auth_object = nil)
    ["color", "size", "product_name"]
  end

  has_many(
    :productboardposts,
    class_name:   'Productboardpost',
    foreign_key:  'listing_id',
    inverse_of:   :listing,
    dependent:    :destroy
  )

  has_many(
    :bag_items,
    class_name: 'Bag_Item',
  )


end
