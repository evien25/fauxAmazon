# == Schema Information
#
# Table name: users
#
#  id                     :bigint           not null, primary key
#  email                  :string           default(""), not null
#  encrypted_password     :string           default(""), not null
#  isAdmin                :boolean
#  remember_created_at    :datetime
#  reset_password_sent_at :datetime
#  reset_password_token   :string
#  created_at             :datetime         not null
#  updated_at             :datetime         not null
#
# Indexes
#
#  index_users_on_email                 (email) UNIQUE
#  index_users_on_reset_password_token  (reset_password_token) UNIQUE
#
class User < ApplicationRecord
  # Devise modules and other setup
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_one :bag, inverse_of: :user, dependent: :destroy

  has_one :user_reward

  def add_reward_points(points)
    user_reward = self.user_reward || UserReward.create(user: self)
    user_reward.increment!(:reward_points, points)
  end

  def subtract_reward_points(points)
    user_reward = self.user_reward || UserReward.create(user: self)
    new_reward_points = user_reward.reward_points - points
    new_reward_points = [new_reward_points, 0].max
    user_reward.update!(reward_points: new_reward_points)
  end

  def total_reward_points
    user_reward&.reward_points.to_i
  end


  after_create :create_cart

  has_many :orders, class_name: 'Order', inverse_of: :user, foreign_key: 'user_id'



  has_many(
    :quizzes,
    class_name: 'Quiz'
  )

  has_one(
    :collection,
    class_name: 'Collection',
    dependent: :destroy
  )


  private

  def create_cart
    Bag.create(user: self, total: 0) unless bag.present?
  end


end
