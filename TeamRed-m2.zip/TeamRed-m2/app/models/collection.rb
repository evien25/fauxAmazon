# == Schema Information
#
# Table name: collections
#
#  id          :bigint           not null, primary key
#  blue_count  :integer
#  green_count :integer
#  pink_count  :integer
#  red_count   :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  user_id     :bigint
#
class Collection < ApplicationRecord

    belongs_to(
        :user,
        class_name: "User",
    )

    

    def check_collection
        unlocked_collections = []

        if blue_count >= 4
           unlocked_collections << 'Blue' 
        end

        if red_count >= 4
            unlocked_collections << 'Red' 
        end

        if green_count >= 4
            unlocked_collections << 'Green' 
        end

        if pink_count >= 4
            unlocked_collections << 'Pink' 
        end

        unlocked_collections
    end

    def secret_item
        unlocked_collections = check_collection
        secret_items = []

        unlocked_collections.each do |color|
            case color
            when 'Red'
                secret_items << "Secret Red Bear"
            when 'Blue'
                secret_items << "Secret Blue Ghost"
            when 'Green'
                secret_items << "Secret Green Mantis"
            when 'Pink'
                secret_items << "Secret Pink Unicorn"
            end
        end

        Listing.where(product_name: secret_items)
    end

end
