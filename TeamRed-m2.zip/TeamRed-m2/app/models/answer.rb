# == Schema Information
#
# Table name: answers
#
#  id           :bigint           not null, primary key
#  answer       :string           not null
#  question_num :integer          not null
#  created_at   :datetime         not null
#  updated_at   :datetime         not null
#  quiz_id      :bigint           not null
#
# Indexes
#
#  index_answers_on_quiz_id  (quiz_id)
#
# Foreign Keys
#
#  fk_rails_...  (quiz_id => quizzes.id)
#
class Answer < ApplicationRecord

    # belongs to relationship of answers-to-quiz
    belongs_to(
       :quiz,
       class_name:  'Quiz',
    )

end
