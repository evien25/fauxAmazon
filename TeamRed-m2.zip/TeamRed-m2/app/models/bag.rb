# == Schema Information
#
# Table name: bags
#
#  id         :bigint           not null, primary key
#  total      :decimal(, )
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  user_id    :bigint           not null
#
# Indexes
#
#  index_bags_on_user_id  (user_id)
#
# Foreign Keys
#
#  fk_rails_...  (user_id => users.id)
#
class Bag < ApplicationRecord
  has_many :bag_items, class_name: "BagItem", inverse_of: :bag, foreign_key: "bag_id"
  belongs_to :user, class_name: "User", inverse_of: :bag, foreign_key: "user_id"
end

