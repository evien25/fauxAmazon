# == Schema Information
#
# Table name: payments
#
#  id          :bigint           not null, primary key
#  card_number :integer
#  cvc         :integer
#  exp         :datetime
#  zip         :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class Payment < ApplicationRecord
end
