# == Schema Information
#
# Table name: quizzes
#
#  id         :bigint           not null, primary key
#  created_at :datetime         not null
#  updated_at :datetime         not null
#  user_id    :bigint           not null
#
# Indexes
#
#  index_quizzes_on_user_id  (user_id)
#
# Foreign Keys
#
#  fk_rails_...  (user_id => users.id)
#
class Quiz < ApplicationRecord

    # belongs to relationship of quizzes-to-user
    belongs_to(
        :user,
        class_name: 'User',
    )

    # has many relationship of quiz-to-answers
    has_many(
        :answers,
        class_name: 'Answer',
        dependent:  :destroy
    )

    # necessary in order to permit the answer model as an attribute
    # reference (also in controller)
    # http://railscasts.com/episodes/196-nested-model-form-revised
    accepts_nested_attributes_for :answers

end
