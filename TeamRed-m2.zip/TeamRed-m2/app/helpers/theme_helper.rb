module ThemeHelper
    def determine_theme(user)
        latest_quiz = user.quizzes.order(created_at: :desc).first
        return nil unless latest_quiz

        ans_1 = latest_quiz.answers.find_by(question_num: 1).answer.to_i
        ans_2 = latest_quiz.answers.find_by(question_num: 2).answer
        ans_3 = latest_quiz.answers.find_by(question_num: 3).answer
        ans_4 = latest_quiz.answers.find_by(question_num: 4).answer

        # theme1.css - winter/ice theme
        # theme2.css - summer/fire theme
        # theme3.css - fall/forest theme
        # theme4.css - spring/love theme
        # need to add more logic to quiz/theme relationship

        if ans_1 < 67 && (ans_2 == 'Winter' || ans_3 == 'Blue' || ans_4 == 'Wimpy')
            'theme1'
        elsif ans_1 > 67 && (ans_2 == 'Summer' || ans_3 == 'Red' || ans_4 == 'Insane')
            'theme2'
        else
            nil
        end

    end

    
end