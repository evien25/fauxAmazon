// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"

import "popper"
import "bootstrap"
import * as autosize from "autosize"

document.addEventListener("turbo:load", () => {
const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
})

document.addEventListener("turbo:load", () => {
autosize(document.querySelectorAll('textarea'))
})

document.addEventListener('DOMContentLoaded', () => {
    const minusButtons = document.querySelectorAll('.quantity-button.minus');
    const plusButtons = document.querySelectorAll('.quantity-button.plus');
    const quantityInputs = document.querySelectorAll('.quantity-input');
  
    minusButtons.forEach(button => {
      button.addEventListener('click', () => {
        const input = button.nextElementSibling;
        let value = parseInt(input.value, 10);
        if (value > 1) {
          input.value = value - 1;
          updateQuantity(input.dataset.id, input.value);
        }
      });
    });
  
    plusButtons.forEach(button => {
      button.addEventListener('click', () => {
        const input = button.previousElementSibling;
        let value = parseInt(input.value, 10);
        input.value = value + 1;
        updateQuantity(input.dataset.id, input.value);
      });
    });
  
    function updateQuantity(itemId, quantity) {
      // Send AJAX request or update the cart in some way
      // Example:
      fetch(`/cart/update/${itemId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ quantity })
      }).then(response => {
        if (response.ok) {
          // Optionally update the cart UI
        }
      });
    }
  });


  
  