//= link application.css
//= link application.js
//= link controllers/application.js
//= link controllers/hello_controller.js
//= link controllers/index.js
//= link theme1.css
//= link theme2.css