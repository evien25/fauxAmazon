class PagesController < ApplicationController
  def store
    @user = current_user

    @recommended_listings = []
    @other_listings = Listing.all

    if @user && @user.quizzes.any?
      latest_quiz = @user.quizzes.order(created_at: :desc).first

      if latest_quiz
        color_ans = latest_quiz.answers.find_by(question_num: 3).answer

        @recommended_listings = Listing.where(color: color_ans)
        @other_listings = Listing.where.not(id: @recommended_listings.pluck(:id))
      end
    end

    @q = @other_listings.ransack(params[:q])
    @listings = @q.result(distinct: true).page(params[:page]).per(100)

    render :store
  end




  def collections
    @user = current_user
    @listings = Listing.all
    render :collections
  end
  def rewards
    @user=current_user
    @reward_plushes = RewardPlush.all
    render :rewards
  end

  def add_item
    @reward_plushes = RewardPlush.find(params[:id])
    @user_bag = Bag.find_by(user_id: current_user.id)

    unless @user_bag
      flash[:error] = "Your bag could not be found."
      redirect_to some_path # Adjust this as needed
      return
    end

    existing_item = @user_bag.bag_items.find_by(product_name: @reward_plushes.product_name)

    if existing_item.nil?
      Bag.transaction do
        BagItem.create!(product_name: @reward_plushes.product_name, price: 0.00, quantity: 1, bag_id: @user_bag.id)
        @user_bag.total += 0
        current_user.subtract_reward_points(@reward_plushes.points_required)
        @user_bag.save!
        flash[:success] = "Item added to your cart."
      end
    else
      flash[:error] = "Item already in Cart"
    end

    redirect_to user_cart_path
  end

  def show
    @reward_plushes = RewardPlush.find(params[:id])
    render :show
  end
end
