class AdmininventoryController < ApplicationController
  def index
    @products = Product.all
    render :index
  end


  def edit
    @product = Product.find(params[:id])
    render :edit
  end

  def update
    @product = Product.find(params[:id])
    if @product.update(product_params)
      @listing = Listing.find_by(product_name: @product.product_name)
      
      if @listing&.update(listing_params)
        flash[:success] = 'Product and Listing Updated'
        redirect_to dashboard_inventory_path
      else
        flash.now[:error] = 'Listing Failed to Update'
        render :edit, status: :unprocessable_entity
      end
    else
      flash.now[:error] = 'Product Failed to Update'
      render :edit, status: :unprocessable_entity
    end
  end

  def show
    @product = Product.find(params[:id])
    render :show
  end

  def destroy
    @product = Product.find(params[:id])
    @associated_listing = Listing.find_by(product_name: @product.product_name)
    if @associated_listing != nil
      @associated_listing.destroy
    end 
    @product.destroy
    flash.now[:error] = 'Product Removed From Inventory and Listings'
    redirect_to dashboard_inventory_path, status: :see_other
  end



  def product_params
    params.require(:product).permit(:price, :product_name, :quantity)
  end
  
  def listing_params
    # Only permit the attributes that the Listing model requires
    params.require(:product).permit(:product_name, :price)
  end

  

end
