class ProductboardpostsController < ApplicationController

  def index
    @listing = Listing.find(params[:listing_id])
    @productboardposts = @listing.productboardposts
    render :index
  end

  def show
    @listing = Listing.find(params[:listing_id])
    @productboardpost = @listing.productboardposts.find(params[:id])
    render :show
  end

  def new
    @listing = Listing.find(params[:listing_id])
    @productboardpost = Productboardpost.new
    render :new
  end

  def create
    @listing = Listing.find(params[:listing_id])
    @productboardpost = @listing.productboardposts.build(params.require(:productboardpost).permit(:post_name, :post_description, :images))
    if @productboardpost.save
      flash[:success] = 'Post saved successfully'
      redirect_to productboardposts_url(@listing)
    else
      flash.now[:error] = 'Post could not be saved'
      render :new, status: :unprocessable_entity
    end
  end

  def edit
    @listing = Listing.find(params[:listing_id])
    @productboardpost = @listing.productboardposts.find(params[:id])
    render :edit
  end

  def update
    @listing = Listing.find(params[:listing_id])
    @productboardpost = @listing.productboardposts.find(params[:id])
    if @productboardpost.update(params.require(:productboardpost).permit(:post_name, :post_description, :images))
      flash[:success] = 'Post updated successfully'
      redirect_to productboardpost_url(@listing, @productboardpost)
    else
      flash.now[:error] = 'Post could not be updated'
      render :edit, status: unprocessable_entity
    end
  end

  def destroy
    @listing = Listing.find(params[:listing_id])
    @productboardpost = @listing.productboardposts.find(params[:id])
    @productboardpost.destroy
    flash[:success] = 'Post deleted successfully'
    redirect_to productboardposts_url(@listing), status: :see_other
  end

end
