class AdminlistingsController < ApplicationController
before_action :authenticate_user!
before_action :require_admin


  def index
    @listings = Listing.all
    render :index
  end

  def new
    @listing = Listing.new
    @product = Product.new
  end

  def create
    @listing = Listing.new(listing_params)
  
    if @listing.save
      # Check if the product already exists
      existing_product = Product.find_by(product_name: @listing.product_name)
  
      if existing_product
        # Product exists, so pull information from it
        flash[:success] = 'Product was Pulled From Inventory'
        @listing.product_name = existing_product.product_name
        @listing.price = existing_product.price
        @listing.product_description = existing_product.product_description
        if existing_product.images.attached?
          @listing.images = existing_product.images
        end
      else
        # Product does not exist, so create it
        flash[:success] = 'Listing Successfully Created'
        @product = Product.create!(
          product_name: @listing.product_name,
          product_description: @listing.product_description,
          price: @listing.price,
          quantity: 1
        )
      end
  
      # Save the listing with the correct information
      @listing.save if @listing.changed?
  
      redirect_to dashboard_listings_url
    else
      flash.now[:error] = 'Listing Creation Failed'
      render :new, status: :unprocessable_entity
    end
  end

    def destroy
      @listing = Listing.find(params[:id])
      @listing.destroy
      flash[:error] = 'Removed From Listings'
      redirect_to dashboard_listings_path, status: :see_other
    end
  

    def edit
      @listing = Listing.find(params[:id])
      render :edit
    end

    def update
      @listing = Listing.find(params[:id])
      
      if @listing.update(listing_params)
        @product = Product.find_by(product_name: @listing.product_name)
        
        if @product
          @product.update(
            product_name: @listing.product_name,
            product_description: @listing.product_description,
            price: @listing.price
          )
        end
  
        flash[:success] = 'Listing and Product Successfully Updated'
        redirect_to dashboard_listings_path
      else
        flash.now[:error] = 'Listing Update Failed'
        render :edit, status: :unprocessable_entity
      end
    end

  def require_admin
    unless current_user.isAdmin
      flash[:alert] = "You are not authorized to access this page."
      redirect_to root_path
    end
  end

  private

def listing_params
  params.require(:listing).permit(:product_name, :product_description, :price, :color, :size, :images)
end


end

