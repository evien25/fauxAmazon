class QuizController < ApplicationController
    before_action :authenticate_user!

    def index
        @quiz = Quiz.new
        4.times { @quiz.answers.build }
        render :index
    end

    def create
        @quiz = current_user.quizzes.new(params.require(:quiz).permit(answers_attributes: [:question_num, :answer]))
        if @quiz.save
            flash[:success] = 'Quiz saved!'
            redirect_to store_path
        else
            flash[:error] = 'Quiz save unseccessfull'
            redirect_to quiz_path
        end
    end

end

# references for nested model forms
# http://railscasts.com/episodes/196-nested-model-form-revised