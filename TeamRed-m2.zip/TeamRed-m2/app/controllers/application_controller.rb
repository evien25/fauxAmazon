class ApplicationController < ActionController::Base
    before_action :initialize_ransack
    before_action :authenticate_user!

    private

    def initialize_ransack
        @q = Listing.ransack(params[:q])
    end
end
