class RewardsController < ApplicationController
  before_action :authenticate_user!
  before_action :require_admin

  def index
    @reward_plushes = RewardPlush.all
    render :index
  end
      def new
        @reward_plushes = RewardPlush.new
        @product = Product.new
        render :new
      end


    def create
      @reward_plushes = RewardPlush.new(reward_plush_params)
      @reward_plushes.save if @reward_plushes.changed?
      redirect_to reward_plushies_url
    end

    def edit
      @reward_plushes = RewardPlush.find(params[:id])
      render :edit
    end

      def destroy
        @reward_plushes = RewardPlush.find(params[:id])
        @reward_plushes.destroy
        flash[:error] = 'Removed From Rewards'
        redirect_to reward_plushies_path, status: :see_other
      end

      def update
        @reward_plushes = RewardPlush.find(params[:id])

        if @reward_plushes.update(reward_plush_params)
          flash[:success] = 'Reward Plushie Updated'
          redirect_to reward_plushies_path
        else
          flash.now[:error] = 'Rewards Update Failed'
          render :edit, status: :unprocessable_entity
        end
      end


    def require_admin
      unless current_user.isAdmin
        flash[:alert] = "You are not authorized to access this page."
        redirect_to root_path
      end
    end

    private

    def reward_plush_params
      params.permit(:product_name, :product_description, :points_required, :images)
    end
end
