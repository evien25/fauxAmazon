Rails.application.routes.draw do
  devise_for :users
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  root "pages#store"
  get 'store', to: 'pages#store', as: 'store'
  get 'store/collections', to: 'pages#collections', as: 'collections'
  get 'store/rewards', to: 'pages#rewards', as: 'rewards'



  get 'store/cart/checkout', to: 'order#checkout', as: 'checkout'
  post 'store/cart/checkout', to: 'order#create', as: 'create_order'

  resources :users do
    member do
      patch 'store/cart/checkout', to: 'order#checkout'
    end
  end


  get 'store/rewards/:id/cart', to: 'pages#add_item', as: 'add_reward'
  get 'store/rewards/:id', to: 'pages#show', as:'rewardplush'


  get 'store/history', to: 'order#order_history', as: 'user_history'
  get 'store/listings/:id', to: 'listings#show', as: 'store_listing'

  get 'store/cart', to: 'cart#index', as: 'user_cart'
  get 'store/listings/add_cart/:id', to: 'listings#add_item', as: 'add_item'
  delete 'store/cart/:id', to: 'cart#destroy', as: 'remove_item'
  get 'store/dashboard', to: 'dashboard#index', as: 'dashboard'


  #inventory manipulation
  get 'store/dashboard/inventory/:id', to: 'admininventory#show', as: 'dashboard_inventory_show'
  delete 'store/dashboard/inventory/:id', to: 'admininventory#destroy', as: 'delete_dashboard_inventory'
  patch 'store/dashboard/inventory/:id/edit', to: 'admininventory#update'
  get 'store/dashboard/inventory/:id/edit', to: 'admininventory#edit', as: 'edit_dashboard_inventory'
  get 'store/dashboard/inventory', to: 'admininventory#index', as: 'dashboard_inventory'



  #listing manipulation
  get 'store/dashboard/listings', to: 'adminlistings#index', as: 'dashboard_listings'
  patch 'store/dasboard/listings/:id/edit', to: 'adminlistings#update'
  delete 'store/dasboard/listings/:id', to: 'adminlistings#destroy', as: 'remove_listing'
  get 'store/dasboard/listings/:id/edit', to: 'adminlistings#edit', as: 'edit_listing'
  get 'store/dashboard/listings/new', to: 'adminlistings#new', as: 'dashboard_listings_new'
  post 'store/dashboard/listings', to: 'adminlistings#create'


  #reward manipulation
  get 'store/dashboard/listings/rewards', to: 'rewards#index', as: 'reward_plushies'
  patch 'store/dashboard/listings/rewards/:id/edit', to: 'rewards#update'
  delete 'store/dashboard/listings/:id', to: 'rewards#destroy', as: 'remove_reward'
  get 'store/dashboard/listings/rewards/:id/edit', to: 'rewards#edit', as: 'edit_reward'
  get 'store/dashboard/listings/rewards/new', to: 'rewards#new', as: 'reward_listing_new'
  post 'store/dashboard/listings/rewards', to: 'rewards#create'

  # Quiz paths
  get 'store/quiz', to: 'quiz#index', as: 'quiz'
  post 'store/quiz', to: 'quiz#create'

  # product board paths
  get 'store/listings/:listing_id/productboardposts', to: 'productboardposts#index', as: 'productboardposts'
  post 'store/listings/:listing_id/productboardposts', to: 'productboardposts#create'
  get 'store/listings/:listing_id/productboardposts/new', to: 'productboardposts#new', as: 'new_productboardpost'
  get '/store/listings/:listing_id/productboardposts/:id/edit', to: 'productboardposts#edit', as: 'edit_productboardpost'
  get 'store/listings/:listing_id/productboardposts/:id', to: 'productboardposts#show', as: 'productboardpost'
  patch '/store/listings/:listing_id/productboardposts/:id', to: 'productboardposts#update'
  delete '/store/listings/:listing_id/productboardposts/:id', to: 'productboardposts#destroy'




end
