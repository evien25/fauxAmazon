# == Schema Information
#
# Table name: productboardposts
#
#  id               :bigint           not null, primary key
#  post_description :string
#  post_name        :string
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  listing_id       :bigint
#
# Indexes
#
#  index_productboardposts_on_listing_id  (listing_id)
#
# Foreign Keys
#
#  fk_rails_...  (listing_id => listings.id)
#
require "test_helper"

class ProductboardpostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
