class OrderController < ApplicationController
  before_action :ensure_bag_not_empty, only: [:checkout, :create]

  def checkout
  @items = current_user.bag.bag_items
  @order = Order.new
  render :checkout
  end

  def create
    @items = current_user.bag.bag_items
    @order = Order.new(order_params)
    @order.total = current_user.bag.total
    @order.points = 0
    @order.user = current_user


   


    if @order.save
      flash[:success] = 'Purchase Successful'
      @items.update_all(orders_id: @order.id)
      current_user.bag.update(total: 0)
      points_earned = calculate_points(@order)
      current_user.add_reward_points(points_earned)
      current_user.bag.bag_items.clear
      redirect_to store_path
    else


      flash.now[:error] = 'Purchase Could Not Be Made'
      render :checkout, status: :unprocessable_entity
    end
  end

  def ensure_bag_not_empty
    if Bag.find_by(user_id: current_user) == nil
      flash[:error] = 'Your cart is empty. Please add items to your cart before checking out.'
      redirect_to user_cart_path
    end
  end


  def order_history
    @history = current_user.orders
    render :order_history
  end

  def order_params
    params.require(:order).permit(:card_number, :cvc, :email, :exp, :first_name, :last_name, :state, :street_address, :street_address_2, :zip, :city)
  end

  def calculate_points(order)

    (order.total * 10).to_i
  end
end
