class CollectionsController < ApplicationController
    before_action :authenticate_user!

    def index
        @collection = current_user.collection

        if @collection
            @secret_items = @collection.secret_item
        else
            flash[:error] = "You don't have any collections unlocked."
            redirect_to store_path

        end

        render 'pages/collections'
    end
end
