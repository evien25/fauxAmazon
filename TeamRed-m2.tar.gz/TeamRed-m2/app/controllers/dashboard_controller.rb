class DashboardController < ApplicationController
  before_action :authenticate_user!
  before_action :require_admin
  
  def index
    render :index
  end

  def require_admin
    unless current_user.isAdmin
      flash[:alert] = "You are not authorized to access this page."
      redirect_to root_path
    end
  end


end
