class CartController < ApplicationController
  before_action :authenticate_user!

  def index
    @cart = Bag.find_by(user_id: current_user.id) || Bag.create(user_id: current_user.id)
    @items = @cart.bag_items if @cart.present?
    @total = @cart.total
    render :index
  end

  
  def destroy
    @item = BagItem.find(params[:id])
    @item.destroy
    @cart = Bag.find_by(user_id: current_user.id)
    @cart.total -= @item.price
    @cart.save
    flash.now[:success] = 'Removed From Cart'
    redirect_to user_cart_path, status: :see_other
  end

end
