class ListingsController < ApplicationController
 

  def show
    @listing = Listing.find(params[:id])
    render :show
  end

  def add_item
    @listing = Listing.find(params[:id])
    @user_bag = Bag.find_by(user_id: current_user.id)
  
    unless @user_bag
      flash[:error] = "Your bag could not be found."
      redirect_to some_path # Adjust this as needed
      return
    end
  
    existing_item = @user_bag.bag_items.find_by(product_name: @listing.product_name)
  
    if existing_item.nil?
      Bag.transaction do
        BagItem.create!(product_name: @listing.product_name, price: @listing.price, quantity: 1, bag_id: @user_bag.id, listing_id: @listing.id)
        @user_bag.total += @listing.price
        @user_bag.save!
        flash[:success] = "Item added to your cart."
      end
    else
      flash[:error] = "Item already in Cart"
    end
  
    redirect_to user_cart_path
  end
  

  

end
