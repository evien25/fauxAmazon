# == Schema Information
#
# Table name: orders
#
#  id               :bigint           not null, primary key
#  card_number      :string
#  city             :string
#  cvc              :integer
#  email            :string
#  exp              :date
#  first_name       :string
#  last_name        :string
#  points           :integer
#  state            :string
#  street_address   :string
#  street_address_2 :string
#  total            :decimal(, )
#  zip              :integer
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#  user_id          :bigint
#
# Indexes
#
#  index_orders_on_user_id  (user_id)
#
# Foreign Keys
#
#  fk_rails_...  (user_id => users.id)
#
class Order < ApplicationRecord
  belongs_to :user, class_name: 'User', inverse_of: :orders, foreign_key: 'user_id'

  has_many :bag_items, class_name: "BagItem", inverse_of: :order, foreign_key: 'orders_id'

  after_create :update_collection_count


  validates :first_name, presence: { message: "Cannot be blank" }
  validates :last_name, presence: { message: "Cannot be blank" }
  validates :card_number, presence: true, format: { with: /\A\d{15}\z/, message: "must be exactly 15 digits" }
  validates :state, presence: { message: "State cannot be blank" }
  validates :zip, presence: { message: "Zip cannot be blank" }
  validates :street_address, presence: { message: "Street Address cannot be blank" }
  validates :email, presence: { message: "Email cannot be blank" }
  validates :cvc, presence: { message: "cvc cannot be blank" }

  private

  def update_collection_count
    if user.collection
      collection = user.collection
    else
      collection = user.create_collection(
        blue_count: 0,
        red_count: 0,
        green_count: 0,
        pink_count: 0
      )
      puts "created new collection for user"
    end

    bag_items.each do |item|
      case item.listing.color
      when 'Blue'
        collection.update_column(:blue_count, collection.blue_count + 1)
      when 'Red'
        collection.update_column(:red_count, collection.red_count + 1)
      when 'Green'
        collection.update_column(:green_count, collection.green_count + 1)
      when 'Pink'
        collection.update_column(:pink_count, collection.pink_count + 1)
      end
    end
  end


 
end
