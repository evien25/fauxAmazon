# == Schema Information
#
# Table name: reward_plushes
#
#  id                  :bigint           not null, primary key
#  points_required     :integer
#  product_description :string
#  product_name        :string
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#
class RewardPlush < ApplicationRecord
  has_many_attached :images

end
