class CreateRewardPlushes < ActiveRecord::Migration[7.0]
  def change
    create_table :reward_plushes do |t|
      t.string :product_name
      t.string :product_description
      t.integer :points_required

      t.timestamps
    end
  end
end
