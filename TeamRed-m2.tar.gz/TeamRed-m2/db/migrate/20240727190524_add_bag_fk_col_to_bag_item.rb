class AddBagFkColToBagItem < ActiveRecord::Migration[7.0]
  def change
    add_reference :bag_items, :bag, foreign_key: true
  end
end
