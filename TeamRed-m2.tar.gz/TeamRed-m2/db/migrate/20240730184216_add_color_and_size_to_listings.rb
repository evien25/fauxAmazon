class AddColorAndSizeToListings < ActiveRecord::Migration[7.0]
  def change
    add_column :listings, :color, :string
    add_column :listings, :size, :string
  end
end
