class CreateProductboardposts < ActiveRecord::Migration[7.0]
  def change
    create_table :productboardposts do |t|
      t.string :post_name
      t.string :post_description

      t.timestamps
    end
  end
end
