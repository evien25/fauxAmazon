class CreateQuizzes < ActiveRecord::Migration[7.0]
  def change
    create_table :quizzes do |t|
      # created user column in data table, disables NULL for user_id in table
      t.references :user, null: false, foreign_key: true

      t.timestamps
    end
  end
end
