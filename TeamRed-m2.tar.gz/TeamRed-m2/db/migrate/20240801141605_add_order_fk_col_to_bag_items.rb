class AddOrderFkColToBagItems < ActiveRecord::Migration[7.0]
  def change
    add_reference :bag_items, :orders, foreign_key: { to_table: :orders }
  end
end
