class CreateProducts < ActiveRecord::Migration[7.0]
  def change
    create_table :products do |t|
      t.string :product_name
      t.text :product_description
      t.float :price
      t.integer :quantity
      t.boolean :popular
      t.string :color
      t.string :size
      t.integer :times_bought

      t.timestamps
    end
  end
end
