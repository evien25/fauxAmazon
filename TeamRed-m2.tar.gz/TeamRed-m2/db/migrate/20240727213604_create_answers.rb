class CreateAnswers < ActiveRecord::Migration[7.0]
  def change
    create_table :answers do |t|
      # adds a quiz reference for answers, does not allow quiz_id reference to be null for answers
      t.references :quiz, null: false, foreign_key: true

      # disables ability to have NULL in database for answers
      t.integer :question_num, null: false
      t.string :answer, null: false

      t.timestamps
    end
  end
end
