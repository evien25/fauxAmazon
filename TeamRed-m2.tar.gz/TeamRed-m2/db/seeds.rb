# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

#admin

justin = User.create!(
  email: 'justin@mysticraft.com',
  password: 'J$tin_MystiCr@ft23!',
  isAdmin: 'true'
)

caroline = User.create!(
  email: 'caroline@mysticraft.com',
  password: 'C@rol1n@_MysticR0ck!',
  isAdmin: 'true'
)

tjay = User.create!(
  email: 'tjay@mysticraft.com',
  password: 'Tj@y_Mystic4ft#2024',
  isAdmin: 'true'
)

eric = User.create!(
  email: 'eric@mysticraft.com',
  password: 'EriC_My5tic@ft!2024',
  isAdmin: 'true'
)

guestuser = User.create!(
  email: 'guestuser@email.com',
  password: 'guestuser'
)

listings = [
  { product_name: "Dragon Plushie", product_description: "A cute, hand-crocheted dragon plushie made with soft yarn.", price: 25.99, color: "Green", size: "Medium" },
  { product_name: "Unicorn Hat", product_description: "A whimsical unicorn hat, perfect for keeping warm and looking magical.", price: 18.50, color: "White", size: "Small" },
  { product_name: "Phoenix Scarf", product_description: "A vibrant scarf inspired by the mythical phoenix, featuring fiery colors.", price: 22.75, color: "Red", size: "Medium" },
  { product_name: "Mermaid Tail Blanket", product_description: "A cozy blanket designed to look like a mermaid tail. Great for lounging.", price: 30.00, color: "Teal", size: "Large" },
  { product_name: "Griffin Amigurumi", product_description: "A detailed griffin amigurumi, combining the features of a lion and an eagle.", price: 27.00, color: "Gold", size: "Medium" },
  { product_name: "Fairy Wings Shawl", product_description: "An elegant shawl with a design that mimics delicate fairy wings.", price: 35.50, color: "Purple", size: "Large" },
  { product_name: "Dragon Scale Gloves", product_description: "Warm gloves with a unique texture resembling dragon scales.", price: 20.00, color: "Black", size: "Small" },
  { product_name: "Pegasus Slippers", product_description: "Comfortable slippers with a pegasus motif, complete with tiny wings.", price: 24.99, color: "Blue", size: "Medium" },
  { product_name: "Yeti Beanie", product_description: "A fun beanie hat that features the face of a friendly yeti.", price: 15.75, color: "White", size: "Small" },
  { product_name: "Elf Ear Warmers", product_description: "Stylish ear warmers that give the appearance of elf ears.", price: 14.25, color: "Green", size: "Small" },
  { product_name: "Centaur Tote Bag", product_description: "A sturdy tote bag with a centaur design, perfect for carrying your crochet projects.", price: 19.50, color: "Brown", size: "Large" },
  { product_name: "Kraken Blanket", product_description: "An ocean-themed blanket featuring the legendary kraken.", price: 32.00, color: "Navy", size: "Large" },
  { product_name: "Cyclops Eye Pillow", product_description: "A quirky pillow shaped like a cyclops eye, great for naps.", price: 12.99, color: "Gray", size: "Small" },
  { product_name: "Basilisk Headband", product_description: "A stylish headband with a basilisk design, adding a mythical touch to your outfit.", price: 17.50, color: "Green", size: "Medium" },
  { product_name: "Gnome Garden Set", product_description: "A set of small gnome figurines to decorate your garden or home.", price: 28.00, color: "Multi", size: "Small" },
  { product_name: "Hydra Keychain", product_description: "A multi-headed hydra keychain, perfect for keeping track of your keys.", price: 8.99, color: "Purple", size: "Small" },
  { product_name: "Chimera Cushion", product_description: "A comfortable cushion with a chimera design, featuring a lion, goat, and snake.", price: 23.75, color: "Brown", size: "Large" },
  { product_name: "Sphinx Puzzle", product_description: "A crochet puzzle in the shape of a sphinx, challenging and fun.", price: 21.00, color: "Beige", size: "Medium" },
  { product_name: "Werewolf Mittens", product_description: "Warm mittens with a werewolf design, great for cold nights.", price: 19.99, color: "Gray", size: "Medium" },
  { product_name: "Goblin Doll", product_description: "A mischievous goblin doll, perfect for adding some fun to your collection.", price: 13.50, color: "Green", size: "Small" },
  { product_name: "Minotaur Mask", product_description: "A detailed mask of a minotaur, perfect for costume parties.", price: 29.99, color: "Brown", size: "Medium" },
  { product_name: "Nessie Socks", product_description: "Cozy socks with a design inspired by the Loch Ness Monster.", price: 10.50, color: "Blue", size: "Small" },
  { product_name: "Wizard's Wand Holder", product_description: "A stylish holder for your wizard's wand, made from high-quality materials.", price: 15.00, color: "Silver", size: "Small" },
  { product_name: "Dwarf Beard Beanie", product_description: "A fun beanie that comes with a detachable dwarf beard.", price: 17.99, color: "Red", size: "Medium" },
  { product_name: "Centaur Throw Pillow", product_description: "A decorative throw pillow with a centaur design, perfect for your living room.", price: 22.50, color: "Brown", size: "Large" },
  { product_name: "Dryad Garden Gloves", product_description: "Durable garden gloves with a dryad design, ideal for all your gardening needs.", price: 12.00, color: "Green", size: "Small" },
  { product_name: "Satyr Scarf", product_description: "A warm scarf with a playful satyr design, perfect for winter.", price: 18.75, color: "Brown", size: "Medium" },
  { product_name: "Witch's Cauldron Cozy", product_description: "A cozy for your cauldron, keeping it warm and stylish.", price: 14.99, color: "Black", size: "Small" },
  { product_name: "Pixie Dust Bag", product_description: "A small bag for carrying your essentials, inspired by pixie dust.", price: 9.50, color: "Pink", size: "Small" },
  { product_name: "Leprechaun Hat", product_description: "A green hat with a leprechaun design, perfect for St. Patrick's Day.", price: 16.99, color: "Green", size: "Small" },
  { product_name: "Phoenix Feather Quill", product_description: "A quill pen made from a phoenix feather, great for writing letters.", price: 11.25, color: "Gold", size: "Small" },
  { product_name: "Mermaid Jewelry Box", product_description: "A beautiful jewelry box with a mermaid design, perfect for storing your treasures.", price: 19.99, color: "Aqua", size: "Small" },
  { product_name: "Unicorn Hair Brush", product_description: "A hairbrush with a unicorn handle, perfect for adding magic to your morning routine.", price: 8.75, color: "Pink", size: "Small" },
  { product_name: "Dragon Egg Candle", product_description: "A candle shaped like a dragon egg, perfect for adding a mystical touch to your home.", price: 12.50, color: "Gray", size: "Small" },
  { product_name: "Griffin Mug", product_description: "A ceramic mug with a griffin design, great for your morning coffee.", price: 14.00, color: "Brown", size: "Small" },
  { product_name: "Fairy Tale Book", product_description: "A beautifully illustrated book of fairy tales, perfect for bedtime stories.", price: 25.00, color: "Multi", size: "Medium" },
  { product_name: "Vampire Cape", product_description: "A stylish cape that transforms you into a vampire, perfect for Halloween.", price: 20.99, color: "Black", size: "Medium" },
  { product_name: "Zombie Plushie", product_description: "A cute plushie of a zombie, perfect for fans of the undead.", price: 15.50, color: "Green", size: "Medium" },
  { product_name: "Ghost Night Light", product_description: "A night light shaped like a ghost, providing a comforting glow in the dark.", price: 10.99, color: "White", size: "Small" },
  { product_name: "Secret Red Bear", product_description: "This legendary, red bear haunts the dreams of many young children...", price: 9.99, color: "Red", size: "Large" },
  { product_name: "Secret Blue Ghost", product_description: "Don't turn off the lights, or else this amazing plushie will appear!", price: 9.99, color: "Blue", size: "Large" },
  { product_name: "Secret Pink Unicorn", product_description: "Keep it secret, keep it classic. Unicorn.", price: 9.99, color: "White", size: "Large" },
  { product_name: "Secret Green Mantis", product_description: "This magic mantis will teach you the ways of the warrior...", price: 9.99, color: "Green", size: "Large" }
]
reward_plushes = [
  { product_name: "Ghost Night Light", product_description: "A night light shaped like a ghost, providing a comforting glow in the dark.", points: 1000}
]

  listings.each do |listing|
    Listing.create(listing)
    Product.create(listing)
  end
